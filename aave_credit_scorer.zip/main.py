import json
import pandas as pd
from collections import defaultdict

def load_data(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def aggregate_features(data):
    wallets = defaultdict(lambda: {
        "total_deposit_usd": 0,
        "total_borrow_usd": 0,
        "total_repay_usd": 0,
        "total_liquidation_usd": 0,
        "count_deposit": 0,
        "count_borrow": 0,
        "count_repay": 0,
        "count_liquidation": 0,
        "timestamps": [],
    })

    for entry in data:
        wallet = entry['userWallet']
        action = entry['action'].lower()
        action_data = entry.get('actionData', {})

        try:
            amount = float(action_data.get('amount', '0')) / 1e18
            price = float(action_data.get('assetPriceUSD', '1'))
            usd_value = amount * price
        except:
            usd_value = 0

        wallets[wallet]["timestamps"].append(entry['timestamp'])

        if action == "deposit":
            wallets[wallet]["total_deposit_usd"] += usd_value
            wallets[wallet]["count_deposit"] += 1
        elif action == "borrow":
            wallets[wallet]["total_borrow_usd"] += usd_value
            wallets[wallet]["count_borrow"] += 1
        elif action == "repay":
            wallets[wallet]["total_repay_usd"] += usd_value
            wallets[wallet]["count_repay"] += 1
        elif action == "liquidationcall":
            wallets[wallet]["total_liquidation_usd"] += usd_value
            wallets[wallet]["count_liquidation"] += 1

    df = pd.DataFrame.from_dict(wallets, orient='index')
    df.index.name = 'wallet'
    df.reset_index(inplace=True)
    df["tx_activity_days"] = df["timestamps"].apply(lambda x: (max(x) - min(x)) / (60 * 60 * 24) if len(x) > 1 else 0)
    df.drop(columns=["timestamps"], inplace=True)
    return df

def score_wallets(df):
    # Score based on weighted formula
    df['score'] = (
        df['total_deposit_usd'].rank(pct=True) * 0.3 +
        df['total_repay_usd'].rank(pct=True) * 0.2 +
        df['tx_activity_days'].rank(pct=True) * 0.1 +
        df['count_repay'].rank(pct=True) * 0.2 +
        (1 - df['total_liquidation_usd'].rank(pct=True)) * 0.2
    ) * 1000
    df['score'] = df['score'].clip(0, 1000).round(2)
    return df

def main():
    data = load_data("user-wallet-transactions.json")
    df = aggregate_features(data)
    df = score_wallets(df)
    df.to_csv("wallet_scores.csv", index=False)
    print("✅ Wallet scoring completed. Output saved to wallet_scores.csv")

if __name__ == "__main__":
    main()
