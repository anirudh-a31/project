# Analysis of Wallet Scores

## Score Distribution

After scoring, wallet scores are binned into ranges (0–100, 100–200, ..., 900–1000). The distribution reveals how many wallets fall into each category and their behavioral traits.

## High Score Wallets (800-1000)
- Consistent deposits and repayments
- Minimal or zero liquidation
- Active across long durations

## Low Score Wallets (0-200)
- No repayments or liquidations triggered
- Minimal activity span or bot-like behavior
- Sudden large borrow with no repay

## Graphical View

(Use notebook or script to generate histogram of scores.)

```python
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("wallet_scores.csv")
plt.hist(df["score"], bins=10, edgecolor='black')
plt.title("Wallet Credit Score Distribution")
plt.xlabel("Score")
plt.ylabel("Number of Wallets")
plt.show()
```
